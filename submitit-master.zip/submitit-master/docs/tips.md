# Tips and caveats

 - It is always preferable to submit functions defined in a module, the traceback will be more explicit in case of error during the execution.
 - On SLURM, use the flush option of print to avoid logs to be buffered `print(text, flush=True)` (on Chronos, the output is unbuffered by default).
 - Contributors are much welcome! You'll probably find some weird behaviors, you can open an issue if so, and solve it if you can ;)
 - the API may still evolve, in particular regarding the locations of pickled data and logs and how they are managed. It is preferable to use a fixed version if you do not want to have any compatibility issue at some point. Use the lastest "release" version that suits you.
 - since the pickled function are references to the module function, if the module changes between the submission and the start
 of the computation, then the computation may not be the one you expect. Similarly, if at the start of the computation, one file cannot
 be run (if you are currently editing it for instance), then the computation will fail. Joblib implements some kind of version check it seems,
 which could be handy.
 - Do not hesitate to create your own `Executor` class: this can be useful to control more precisely how your job are submitted.
 In about 10 lines of code, you can for instance have an executor which creates a new logging folder for each submitted jobs etc...
 - If you want to be able to switch from Chronos/Slurm/local execution easily use the `AutoExecutor`, which provide a shared interface.

## Specific to Slurm
 - While all jobs are requeued after preemption, only Checkpointable classes are requeued after a timeout (since a stateless function is expected to timeout again if it is requeued)
 - Timeouts are requeued a limited number of time (default: 3, see `Executor`) in order to avoid endless jobs.
 - the log/output folder must be chosen carefully: it must be a directory shared between instances, which rules out /tmp. If you
 are not careful with this, you may get job that fails without any log to debug them. Also, it will fill up pretty fast with batch
 files and pickled objects, but no cleaning mechanism is currently implemented.

## Specific to Chronos

### No automatic requeue
The current code can not automatically requeue a preempted job with Chronos.
It will checkpoint it (if you implemented the `checkpoint` method), but you'll have to re-submit it manually (eg `crerun <job_id>`)

### Dev folders
On a FB devserver, your HOME folder, and so your conda environment, is not accessible from the cluster's nodes.
There are several options to make it available for a job scheduled with Chronos:
1. create your conda environment in a shared folder (eg gfsai): `submitit` doesn't support this option.
2. by default, `submitit` will create a archive containing the active conda environment, and copy it to your Executor's folder.
 This folder must be accessible by the cluster's nodes (eg, use gfsai).
 This archive is then copied on the node running the job.
3. Provide a par file created with Buck. Par file are Python executable archive, that you can create with buck if your code is in fbcode (see [Submitit in fbcode](#submitit-in-fbcode)).

For 2., it also means that your working project must be installed in your conda env, so that it's accessible on the node.
Thus, you can't install your project in dev (aka editable) mode. It also means that after any change in the code, you need to reinstall it.
To overcome this issue, you can use `executor.register_dev_folders(folders)`, to specify your working directories that will be shipped to the nodes.
It allows you to modify the code in the registered dev folders, without reinstalling your project each time.

## Debugging

If you want to add breakpoints to a function run by `submitit`, the easiest way is to use the `DebugExecutor` or `AutoExecutor(cluster="debug")`.
This will execute all the "submitted" jobs inside the main process, and your breakpoints will be hit normally.

## Recent breaking changes

 - `executor.map` becomes `executor.map_array` since it is not compatible with `concurrent.futures.Executor.map`.
 - `job.job_id` is now a string instead of an int.
