# Using `nevergrad` with `submitit`

`nevergrad` is a derivative-free optimization toolbox developed at FAIR which can be used to tune network hyperparameters.
These algorithms can be competitive over random search if you have around 10 parameters or more.

## Basics of `nevergrad`

The following is a simplified version of the tutorial in [`nevergrad`'s repository](https://github.com/facebookresearch/nevergrad/README.md), you can find more details there.

### Example of optimization

For the sake of this example, we'll define a function to optimize:
```python
def myfunction(x, y=12):
    return sum((x - .5)**2) + abs(y)
```

Before we can perform optimization, we must define how this function is instrumented, i.e. the values that the parameters
of the function can take. This is done through the `Instrumentation` class.
The following states the first parameter of the function is an array of size 2, and the second a float:

```python
from nevergrad import instrumentation as inst
instrum = inst.Instrumentation(
    inst.var.Array(2),  # first parameter
    y=inst.var.Array(1).asscalar())  # second (named) parameter
```


Then you can initialize an algorithm (here `TwoPointsDE`, a full list can be obtained with `list(optimizerlib.registry.keys())` with
this instrumentation and the budget (number of iterations) it can spend, and run the optimization:
```python
from nevergrad.optimization import optimizerlib
optimizer = optimizerlib.TwoPointsDE(instrumentation=instrum, budget=100)
recommendation = optimizer.optimize(square)
print(recommendation)
>>> Candidate(args=(array([0.500, 0.499]),), kwargs={})
```
`recommendation` holds the optimal attributes `args` and `kwargs` found by the optimizer for the provided function.
In this example, the optimal value will be found in `recommendation.args[0]` and will be a `np.ndarray` of size 2.

### Instrumentation


4 types of variables are currently provided for instrumentation:
- `SoftmaxCategorical`: converts a list of `n` (unordered) categorial variables into an `n`-dimensional space. The returned element will be sampled as the softmax of the values on these dimensions. Be cautious: this process is non-deterministic and makes the function evaluation noisy.
- `OrderedDiscrete`: converts a list of (ordered) discrete variables into a 1-dimensional variable. The returned value will depend on the value on this dimension: low values corresponding to first elements of the list, and high values to the last.
- `Gaussian`: normalizes a `n`-dimensional variable with independent Gaussian priors (1-dimension per value).
- `Array`: casts the data from the optimizaton space into a `np.ndarray` of any shape, to which some transforms can be applied
  (see `asscalar`, `affined`, `exponentiated`, `bounded`). This makes it a very flexible type of variable.
  For instance, one can use it for a logarithmicly distributed value between 0.001 and 1.: `Array(1).asscalar().bounded(0, 3).exponentiated(base=10, coeff=-1)`.
  Also, note that `Gaussian(a, b)` is equivalent to `Array(1).asscalar().affined(a, b)`.

Here is a basic example:
```python
from nevergrad import instrumentation as inst

arg1 = inst.var.OrderedDiscrete(["a", "b"])  # either "a" or "b" (ordered)
arg2 = inst.var.SoftmaxCategorical(["a", "c", "e"])  # "a", "c" or "e" (unordered)
arg4 = inst.var.Array(4, 3).bounded(0, 1)   # an array of size (4, 3) with values between 0 and 1

# the following instrumentation uses these variables (and keeps the 3rd argument constant)
instrum = Instrumentation(arg1, arg2, "constant_argument", arg4)
```

And this is a more realistic instrumentation example for a neural network training:
```python
instru = instrumentation.Instrumentation(
    dataset=instrumentation.var.SoftmaxCategorical(['wikilarge', 'allnli']),
    # Arch
    architecture=instrumentation.var.SoftmaxCategorical(['fconv', 'lightconv', 'fconv_self_att', 'lstm', 'transformer']),
    dropout=instrumentation.var.Array(1).affined(a=0.1, b=.5).bounded(0, 1),
    # Training
    max_tokens=instrumentation.var.OrderedDiscrete(np.arange(500, 20001, 100).tolist()),
    max_epoch=instrumentation.var.Array(1).asscalar(int).bound(1, 50),
    # Optimization
    lr=instrumentation.var.Array(1).asscalar().bounded(0, 3).exponentiated(base=10, coeff=-1)`.
)
```


## Working asynchronously with submitit

To speed up optimization, you probably want to run several function evaluations concurrently.
To do this, you need to notify `nevergrad` at the optimizer initialization that you will have several workers (example: 32 here):

```python
optimizer = optimizerlib.TwoPointsDE(instrumentation=instru, budget=8192, num_workers=32)
```
This, way, the optimizer will be prepared to provide several points to evaluate at once. You have then 2 ways to handle these evaluations:


### Through the optimize method

The `optimize` method takes an executor-like object which is compatible with `submitit` (and `concurrent.futures` and `dask`).
With the following, nevergrad will take care of submitting a job per function evaluation, with at most 32 jobs in parallel:
```python
executor = AutoExecutor(folder=my_folder)
executor.update_parameters(timeout_min=60, partition='learnfair', gpus_per_node=1, cpus_per_task=2)
recommendation = optimizer.optimize(my_function, executor=executor, verbosity=2)
```

### Using the ask and tell interface

`nevergrad` also provides an ask and tell interface:
- `ask()` provides a candidate point to evaluate.
- `tell(x, value)` is used to feed the function evaluation back to `nevergrad`.

In this case you are the one responsible for properly running the optimization procedure. A naive loop with batch evaluation could like like this:
```python
remaining = optimizer.budget - optimizer.num_ask
while remaining:
    candidates = [optimizer.ask() for k in range(remaining)]
    jobs = [executor.submit(my_function, *c.args, **c.kwargs)) for c in candidates]
    for candidate, job in zip(candidates, jobs):
        optimizer.tell(candidate, job.result())
    remaining = optimizer.budget - optimizer.num_ask
recommendation = optimizer.provide_recommendation()
```

### Gotcha

Since a job will be submitted for each function evaluation, using `submitit` executor in `nevergrad` is suitable for evaluations which take at least tens of minutes, not for small evaluations which will overload the cluster and spend more time pending than running.
If you're evaluations are fast, [`fairtask`](https://github.com/fairinternal/fairtask) may then be more suitable since it reserves workers on which you can run several evaluations.
