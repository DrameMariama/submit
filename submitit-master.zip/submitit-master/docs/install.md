# Installation

## Slurm - FAIR cluster

The cluster relies on `conda` for the environment, so make sure your code works in a conda environment!
If you are not familiar with it, here are commands to run to create an environment and install `pip` in the environment.
```bash
module purge
module load anaconda3
conda create -n <name> pip
```
Then run `source activate <name>` to activate it.

`pip` is the simplest way to install `submitit`, so make sure it is installed in your current environment  (check the output path of `which pip`).
Install it if needed: `conda install pip`. Then you can install `submitit` with:

```
pip install git+ssh://git@github.com/fairinternal/submitit@master#egg=submitit
```
This will install `submitit` and its dependencies. You will then be able to run `import submitit` from anywhere inside Python.
You may want to use a specific version (Eg.: `submitit@v0.1.0` instead of `submitit@master`) since the API may still evolve a lot (at least with regards to where the data is stored) and break your code.

You can also install it via https:
```
pip install git+https://github.com/fairinternal/submitit.git@master#egg=submitit
```


**For developpers**: If you want to both use and develop `submitit`, clone `submitit` repository, then, after activating your conda environment `python setup.py develop` from inside the repository.

## Chronos - FB cluster

On a devserver (or devgpu), you may need to install conda (instructions found [here](https://our.internmc.facebook.com/intern/wiki/FAIR/Fair-engineering-resources/py-torch-in-fb-code-and-dev-gpu/)):

First create an alias to simplify proxy use:
```
alias with-proxy="HTTPS_PROXY=http://fwdproxy:8080 HTTP_PROXY=http://fwdproxy:8080 FTP_PROXY=http://fwdproxy:8080 https_proxy=http://fwdproxy:8080 http_proxy=http://fwdproxy:8080 ftp_proxy=http://fwdproxy:8080 http_no_proxy='\''*.facebook.com|*.tfbnw.net|*.fb.com'\'"
```

then install conda:
```
pushd ~/local && \
with-proxy wget https://repo.continuum.io/miniconda/Miniconda3-latest-Linux-x86_64.sh -O miniconda.sh && \
chmod +x miniconda.sh && \
./miniconda.sh -b -p ~/local/miniconda && \
rm -f miniconda.sh
```
and activate it:
```
. ~/local/miniconda/bin/activate
```

Make sure that you can access GitHub through ssh (see [here](https://our.internmc.facebook.com/intern/wiki/Open_Source/Resources/Devserver_GitHub_Access/))
```
ssh -T git@github.com
```
should give you a success message.


Create an environment **containing python** (this is important to be self-contained):
```
with-proxy conda create -n <env_name> python=3.6 --copy
with-proxy conda activate <env_name>
with-proxy conda install pip -y
with-proxy pip install git+ssh://git@github.com/fairinternal/submitit@master#egg=submitit
# or via https: with-proxy pip install git+https://github.com/fairinternal/submitit.git@master#egg=submitit
```

You also need to install `chronos` `c*` binaries (`crun`, `clist` etc...):
```
sudo yum install fb-chronos-scripts
```
Note: You may need to run `fixmyserver` first (if you have `http_proxy` and `https_proxy` already set, you need to `unset` both: `unset http_proxy` and `unset https_proxy`.)

Add the path to your shell (e.g.: bash):
```
echo 'export PATH=/usr/local/chronos/scripts/:$PATH' >> ~/.bashrc
source ~/.bashrc
```

For development, clone `submitit` repository, move into the directory and use:
```
with-proxy pip install . --upgrade
```
Indeed, the package must be installed inside the environment so as to be packaged and sent to the cluster. Alternatively, you can add `submitit` folder to the list of registered folders to be sent to the job using `executor.register_dev_folders([your_submit_folder])`.


### Hipster secure group

Using crun now requires Hipster secure groups.
You can join this [default secure group](https://l.workplace.com/l.php?u=https%3A%2F%2Ffburl.com%2Fpermission%2Fpx7znjt6&h=AT06mGYORoh-D9V9op0sol37-lTkHX7fBlZRVeic_9f_COA8jCoVEWFkImRJNK6vbyPRqwbyhZnLEOw_j1UvkKoM86jvFRYXd3UZRRsyk3z7zTxWF6ifVIgyyAs26DCdDHku6KhKO1g13BLVT-xHvNl7bezNJO9zj9CCQF_1xQ).

If you need to access data protected by ACL, you must be part of the appropriate secure group, and set the parameter `secure_group` in the executor.

```python
executor = AutoExecutor(folder)
executor.update_parameters(secure_group="crun")
```

Be aware that the job won't run with your unix user, but with the user attached to the group. If your job need to write files (eg on gfsai), make sure that the destination directory has the appropriate permissions (777 is fine).

For more details, see this [post](https://fb.workplace.com/groups/322398868131609/permalink/805992749772216/).
