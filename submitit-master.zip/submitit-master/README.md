[![CircleCI](https://circleci.com/gh/fairinternal/submitit.svg?style=svg&circle-token=a3ce2047616a59fc11c96efec19145b5a2b7273e)](https://circleci.com/gh/fairinternal/submitit)

# Submit it!

**Contributors** (chronological): Jérémy Rapin, Louis Martin, Lowik Chanussot, Lucas Hosseini, Fabio Petroni, Francisco Massa, Guillaume Wenzek, Thibaut Lavril, Vinayak Tantia, Andrea Vedaldi (feel free to [contribute](.github/CONTRIBUTING.md) and add your name ;) )

**Points of contact** : Jérémy Rapin (jrapin), Lowik Chanussot (lowik)


Quick install (if you only want to use `submitit`, and not develop it), in a conda environment where `pip` is installed (check `which pip`):
via ssh:
```
pip install git+ssh://git@github.com/fairinternal/submitit@master#egg=submitit
```
or with https:
```
pip install git+https://github.com/fairinternal/submitit.git@master#egg=submitit
```
You can also change `submitit@master` to a version of your choice (Eg., `submitit@v0.2.2`) in order to avoid compatibility issues.
See below for more information and options.


## Documentation

See the following pages for more detailled information:

- [Installing on FAIR cluster or FB cluster](docs/install.md): to have a detailled tutorial on how to install `submitit` on either FAIR cluster or FB cluster.
- [Examples](docs/examples.md): for a bunch of examples dealing with errors, concurrency, multi-tasking etc...
- [Jupyter Notebook tutorial](tutorial.ipynb): for similar examples, easy to run on either slurm or chronos.
- [Structure and main objects](docs/structure.md): to get a better understanding of how `submitit` works, which files are created for each job, and the main objects you will interact with.
- [Checkpointing](docs/checkpointing.md): to understand how you can configure your job to get checkpointed when preempted and/or timed-out.
- [Tips and caveats](docs/tips.md): for a bunch of information that can be handy when working with `submitit`.
- [Hyperparameter search with nevergrad](docs/nevergrad.md): basic example of `nevergrad` usage and how it interfaces with `submitit`.
- [Advanced examples](https://github.com/fairinternal/submitit_examples ) using distributed training (multi-nodes, 1 task per gpu)  with a basic grid search, and distributed inference on CPU showing how to shard data across many jobs. This is in a dedicated repository.


## What is submitit?

### An example is worth a thousand words: performing an addition

From inside the conda environment with submitit installed:

```python
import submitit

def add(a, b):
    return a + b

executor = submitit.AutoExecutor(folder="log_test")  # submission interface (logs are dumped in the folder)
executor.update_parameters(timeout_min=1, partition="dev")  # timeout in min
job = executor.submit(add, 5, 7)  # will compute add(5, 7)
print(job.job_id)  # ID of your job

output = job.result()  # waits for completion and returns output
assert output == 12  # 5 + 7 = 12...  your addition was computed in the cluster
```

The job class also provides tools for reading the log files (`stdout` or `stderr`).

If what you want to run is a command, turn it into a Python function using `submitit.helpers.CommandFunction`, then submit it.
By default stdout is silenced in `CommandFunction`, but it can be unsilenced with `verbose=True`.

**Find more examples [here](docs/examples.md)!!!**



### Goals
The aim of this Python3 package is to be able to launch jobs on Slurm/Chronos painlessly from *inside Python*, using the same submission and job patterns than the standard library package `concurrent.futures`:

Here are a few benefits of using this lightweight package:
 - submit any function, even lambda and script-defined functions.
 - raises an error with stack trace if the job failed.
 - requeue preempted jobs (Slurm only)
 - swap between `submitit` executor and one of `concurrent.futures` executors in a line, so that it is easy to run your code either on slurm, or locally with multithreading for instance.
 - checkpoints stateful callables when preempted or timed-out and requeue from current state (advanced feature).
 - easy access to task local/global rank for multi-nodes/tasks jobs.
 - same code works on FAIR and FB clusters.

### Non-goals

- a commandline tool for running slurm jobs. Here, everything happens inside Python. If this is want you are looking for, you can use `stools` instead for instance.
- a task queue, this only implements the ability to launch tasks, but does not schedule them in any way.
- being used in Python2! This is a Python3.6+ only package :)

Also, for now, this is only a preliminary version of the package. Some parameters may be missing (you are welcome to add them!), and the API may change in the future (though the aim is to keep it mostly compatible with `concurrent.futures`).


### Alternatives

On the FAIR cluster, the main alternative is to have a correctly written bash script. See for instance [P60875797](https://phabricator.internmc.facebook.com/P60875797), the examples provided in the [SLURM FAQ](https://fb.quip.com/Ov7NA1FD3mmx).
You can also run commands easily using [stool](https://github.com/fairinternal/stool) or [fairtask](https://github.com/fairinternal/stool).

On the FB cluster, there are many other tools available at FB.
Have a look to [FAIR Engineering Resources](https://our.internmc.facebook.com/intern/wiki/FAIR/Fair-engineering-resources/pushing-our-cli-tools/), to see if another tools fits your needs better.
