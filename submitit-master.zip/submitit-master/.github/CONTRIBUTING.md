# Contributing to submitit

Feel free to contribute, and if you do, please add your name in the main [README](../README.md) ;)

## Installation

To install `submitit` in development mode (if you wish to contribute to it), clone the repository and run `pip install -e '.[dev]'` from inside the repository folder.

## Testing/Formatting

### Unit tests

Most of the code is covered by unit tests. You can run them with:
```
pytest submitit
```

### Type checking
For type, run `mypy` on `submitit` with:
```
mypy --ignore-missing-imports --strict submitit
```

You can however omit the `--strict` mode for a simplified version of the checks.
If you are not familiar with type checking, don't bother with it, and you may even ignore errors by adding `# type: ignore` at the end of lines flagged as incorrect.
We'll deal with those later if need be.

### Formatting and precommit hooks
We use [`black`](https://github.com/psf/black) for formatting. You can run it with:
```
black submitit
```

Black is included along `isort` and `pylint` in our pre-commit hooks. Once pre-commit hooks are installed with: 
```
pre-commit install
```
`black`, `isort` and `pylint` will run each time you commit (you may have to rerun the commit if you see red in the output ;) ) so that you won't have to worry about it anymore.

## CI

Unit tests, type checks  (in non-strict mode) and black check will be automatically run every time a pull request is submitted/updated.


