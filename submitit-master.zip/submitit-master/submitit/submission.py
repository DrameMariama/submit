import argparse
import os
import signal
import socket
import sys
import time
import traceback
import types
import warnings
from pathlib import Path
from typing import Union

from . import utils
from .logger import get_logger

# pylint: disable=logging-fstring-interpolation


def _slurm_requeue(remaining_timeouts: int) -> None:
    jid = utils.JobEnvironment().job_id
    os.system(f"scontrol requeue {jid}")
    get_logger().info(f"Requeued job {jid} ({remaining_timeouts} remaining timeouts)")


def _local_requeue(remaining_timeouts: int) -> None:
    jid = utils.JobEnvironment().job_id
    get_logger().info(f"Requeued job {jid} ({remaining_timeouts} remaining timeouts)")
    sys.exit(utils.LOCAL_REQUEUE_RETURN_CODE)  # should help noticing if need requeuing


def _exit() -> None:
    # extracted for mocking
    get_logger().info("Exiting gracefully after preemption/timeout.")
    sys.exit(-1)


def _checkpoint(delayed: utils.DelayedSubmission, filepath: Path, countdown: int) -> str:
    """Call the checkpoint method and dump the updated delayed.

    Returns:
    --------
        no_requeue_reason: str
            a string explaining while there was no requeuing, else empty string if requeuing works
    """
    get_logger().info("Calling checkpoint method.")
    if isinstance(delayed.function.checkpoint, types.FunctionType):  # type: ignore
        warnings.warn(
            "DelayedSubmission as checkpoint argument is deprecated, use new non static syntax (cf README)",
            DeprecationWarning,
        )
        ckpt_delayed = delayed.function.checkpoint(delayed)  # type: ignore
    else:
        ckpt_delayed = delayed.function.checkpoint(*delayed.args, **delayed.kwargs)  # type: ignore
    if ckpt_delayed is None:  # if checkpoint returned None, stop there
        return "checkpoint function returned None"
    ckpt_delayed.timeout_countdown = countdown
    with utils.temporary_save_path(filepath) as tmp:
        ckpt_delayed.dump(tmp)
    return ""  # requeues


class SignalHandler:
    def __init__(
        self, job_paths: utils.JobPaths, delayed: utils.DelayedSubmission, local: bool = False
    ) -> None:
        self._job_paths = job_paths
        self._delayed = delayed
        self._timedout = True
        self._local = local
        self._logger = get_logger()

    def sigterm(
        self, signum: signal.Signals, frame: types.FrameType  # pylint:disable=unused-argument
    ) -> None:
        self._logger.warning("Bypassing sigterm.")
        self._timedout = False  # this signal before USR1 means the job was preempted

    def sigusr1(
        self, signum: signal.Signals, frame: types.FrameType  # pylint:disable=unused-argument
    ) -> None:
        case = "timed-out" if self._timedout else "preempted"
        self._logger.warning(f"Caught USR1 signal {signum} on {socket.gethostname()}: this job is {case}.")

        procid = utils.JobEnvironment().global_rank
        if procid:
            self._logger.info(f"Not checkpointing nor requeuing since I am a slave (procid={procid}).")
            # do not sys.exit, because it might kill the master task
            return

        delayed = self._delayed
        countdown = delayed.timeout_countdown - self._timedout
        no_requeue_reason = ""
        if hasattr(delayed.function, "checkpoint"):
            no_requeue_reason = _checkpoint(self._delayed, self._job_paths.submitted_pickle, countdown)
        elif self._timedout:
            no_requeue_reason = "timed-out and not checkpointable"
        if countdown < 0:  # this is the end
            no_requeue_reason = "timed-out too many times"
        if no_requeue_reason:
            # raise an error so as to create "result_pickle" file which notifies the job is over
            # this is caught by the try/except in "process_job"
            message = f"Job not requeued because: {no_requeue_reason}."
            self._logger.info(message)
            raise utils.UncompletedJobError(message)
        # if everything went well, requeue!
        if self._local:
            _local_requeue(countdown)
        else:
            _slurm_requeue(countdown)
        _exit()

    def chronos(
        self, signum: signal.Signals, frame: types.FrameType  # pylint:disable=unused-argument
    ) -> None:
        self._logger.info(f"Caught signal {signal.Signals(signum).name} on {socket.gethostname()}")

        procid = utils.JobEnvironment().global_rank
        if procid:
            self._logger.info(f"Not checkpointing since I am a slave (procid={procid}).")
            # do not sys.exit, because it might kill the master task
            return

        delayed = self._delayed
        if hasattr(delayed.function, "checkpoint"):
            _checkpoint(self._delayed, self._job_paths.submitted_pickle, self._delayed.timeout_countdown)
        _exit()


def process_job(folder: Union[Path, str]) -> None:
    """Loads a pickled job, runs it and pickles the output

    Parameter
    ---------
    cluster: str
        name of the cluster the job is submitted to ('slurm' or 'chronos')
    folder: Path/str
        path of the folder where the job pickle will be stored (with a name containing its uuid)

    Side-effect
    -----------
    Creates a picked output file next to the job file.
    """
    folder = Path(folder)
    env = utils.JobEnvironment()
    paths = utils.JobPaths(folder, job_id=env.job_id, task_id=env.global_rank)
    logger = get_logger()
    logger.info(f"Starting with {env}")
    logger.info(f"Loading pickle: {paths.submitted_pickle}")
    wait_time = 60
    for _ in range(wait_time):
        if not paths.submitted_pickle.exists():
            time.sleep(1)
    if not paths.submitted_pickle.exists():
        raise RuntimeError(
            f"Waited for {wait_time} seconds but could not find submitted jobs in path:\n{paths.submitted_pickle}"
        )
    # pylint: disable=broad-except
    try:
        delayed = utils.DelayedSubmission.load(paths.submitted_pickle)
        handler = SignalHandler(paths, delayed, local=env.cluster == "local")
        if env.cluster in ("slurm", "local"):
            signal.signal(signal.SIGUSR1, handler.sigusr1)
            signal.signal(signal.SIGTERM, handler.sigterm)
        if env.cluster == "chronos":
            signal.signal(signal.SIGUSR1, handler.chronos)
            signal.signal(signal.SIGUSR2, handler.chronos)
            signal.signal(signal.SIGTERM, handler.chronos)
        result = delayed.result()
        with utils.temporary_save_path(paths.result_pickle) as tmppath:  # save somewhere else, and move
            utils.pickle_dump(("success", result), tmppath)
            logger.info("Job completed successfully")
    except Exception as error:  # TODO: check pickle methods for capturing traceback; pickling and raising
        try:
            with utils.temporary_save_path(paths.result_pickle) as tmppath:
                utils.pickle_dump(("error", traceback.format_exc()), tmppath)
        except Exception as dumperror:
            logger.error(f"Could not dump error:\n{error}\n\nbecause of {dumperror}")
        logger.error("Submitted job triggered an exception")
        raise error


def submitit_main() -> None:
    parser = argparse.ArgumentParser(description="Run a job")
    parser.add_argument("folder", type=str, help="Folder where the jobs are stored (in subfolder)")
    args = parser.parse_args()
    process_job(args.folder)
