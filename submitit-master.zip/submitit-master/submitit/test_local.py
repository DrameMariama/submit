import os
import time
from pathlib import Path

import pytest

from . import helpers, local, test_core, utils


def test_local_job(tmp_path: Path) -> None:
    def func(p: int) -> int:
        job_env = utils.JobEnvironment()
        return p * job_env.local_rank

    executor = local.LocalExecutor(tmp_path)
    executor.update_parameters(tasks_per_node=3, nodes=1)
    job1 = executor.submit(func, 1)
    job2 = executor.submit(func, 2)
    assert job1.results() == [0, 1, 2]
    assert job2.results() == [0, 2, 4]


def test_local_job_array(tmp_path: Path) -> None:
    n = 5
    data1, data2 = range(n), range(10, 10 + n)

    def f(x: int, y: int) -> int:
        assert x in data1
        assert y in data2
        return x + y

    executor = local.LocalExecutor(tmp_path)
    jobs = executor.map_array(f, data1, data2)

    assert list(map(f, data1, data2)) == [j.result() for j in jobs]


def test_local_error(tmp_path: Path) -> None:
    def failing_job() -> None:
        raise Exception("Failed on purpose")

    executor = local.LocalExecutor(tmp_path)
    job = executor.submit(failing_job)
    exception = job.exception()
    assert isinstance(exception, utils.FailedJobError)
    traceback = exception.args[0]
    assert "Traceback" in traceback
    assert "Failed on purpose" in traceback


@pytest.mark.skipif(not os.environ.get("SUBMITIT_SLOW_TESTS", False), reason="slow")  # type: ignore
def test_long_running_job(tmp_path: Path) -> None:
    def f(x: int, y: int, sleep: int = 120) -> int:
        time.sleep(sleep)
        return x + y

    executor = local.LocalExecutor(tmp_path)
    executor.update_parameters(timeout_min=5)
    job = executor.submit(f, 40, 2)
    assert job.result() == 42


def test_requeuing(tmp_path: Path) -> None:
    func = helpers.FunctionSequence(verbose=True)
    for _ in range(20):
        func.add(test_core.do_nothing, sleep=1)
    executor = local.LocalExecutor(tmp_path, max_num_timeout=1)
    executor.update_parameters(timeout_min=3 / 60.0, signal_delay_s=1)
    job = executor.submit(func)
    job.wait()
    stdout = job.stdout()
    assert stdout is not None
    assert any("Starting from {x}/20" for x in [1, 2, 3]), f"Should have resumed from a checkpoint:\n{stdout}"
    assert "timed-out too many times" in stdout, f"Unexpected stdout:\n{stdout}"
    assert "(0 remaining timeouts)" in stdout, f"Unexpected stdout:\n{stdout}"


def test_make_subprocess(tmp_path: Path) -> None:
    process = local.start_controller(
        tmp_path, "python -c 'import os;print(os.environ[\"SUBMITIT_LOCAL_JOB_ID\"])'", timeout_min=1
    )
    paths = utils.JobPaths(tmp_path, str(process.pid), 0)
    pg = process.pid
    process.wait()
    stdout = paths.stdout.read_text()
    stderr = paths.stderr.read_text()
    assert stdout and int(stdout.strip()) == pg, f"PID link is broken (stderr: {stderr})"
