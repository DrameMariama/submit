import inspect
import re
import shutil
import subprocess
import sys
import uuid
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Set, Union

from . import _core, utils
from ._core import R


class SlurmInfoWatcher(_core.InfoWatcher):
    # pylint: disable=too-many-instance-attributes

    def _make_command(self) -> Optional[List[str]]:
        # asking for array id will return all status
        # on the other end, asking for each and every one of them individually takes a huge amount of time
        to_check = {x.split("_")[0] for x in self._registered - self._finished}
        if not to_check:
            return None
        command = ["sacct", "-o", "JobID,State"]
        for jid in to_check:
            command.extend(["-j", str(jid)])
        return command

    def get_state(self, job_id: str, mode: str = "standard") -> str:
        """Returns the state of the job
        State of finished jobs are cached (use watcher.clear() to remove all cache)

        Parameters
        ----------
        job_id: int
            id of the job on the cluster
        mode: str
            one of "force" (forces a call), "standard" (calls regularly) or "cache" (does not call)
        """
        info = self.get_info(job_id, mode=mode)
        return info.get("State") or "UNKNOWN"

    def read_info(self, string: Union[bytes, str]) -> Dict[str, Dict[str, str]]:
        """Reads the output of sacct and returns a dictionary containing main information
        """
        if not isinstance(string, str):
            string = string.decode()
        lines = string.splitlines()
        if len(lines) < 3:
            return {}  # one job id does not exist (yet)
        reader = PatternReader(lines[1])  # this is the dashed line
        names = reader.split(lines[0])
        # read all lines
        all_stats: Dict[str, Dict[str, str]] = {}
        for line in lines[2:]:
            stats = {x: y for x, y in zip(names, reader.split(line)) if x and x != " "}
            job_id = stats["JobID"]
            if not job_id or "." in job_id:
                continue
            main_job_id, *array_id = job_id.split("_", 1)

            # Array id are sometimes displayed with weird chars
            try:
                a = int(array_id[0].strip("[+")) if array_id else None
            except Exception as e:  # pylint: disable=broad-except
                warnings.warn(f"Could not interpret {job_id} correctly (please open an issue):\n{e}")
                continue
            if not (array_id and all(x in array_id[0] for x in "[+")):
                all_stats[main_job_id if a is None else f"{main_job_id}_{a}"] = stats
            else:
                # propagate status to unstarted array tasks like: 12445_[12+ PENDING
                # very important to avoid waiting for ever for cancelled jobs
                assert a is not None
                for reg_job_id in self._registered:
                    if reg_job_id.startswith(main_job_id + "_") and int(reg_job_id.split("_")[1]) >= a:
                        all_stats[reg_job_id] = stats
        return all_stats


class SlurmJob(_core.Job[R]):

    _cancel_command = "scancel"
    watcher = SlurmInfoWatcher(delay_s=600)

    def _send_requeue_signal(self, timeout: bool = True) -> None:
        """Sends preemption or timeout signal to the job (for testing purpose)

        Parameter
        ---------
        timedout: bool
            Whether to trigger a job time-out (if False, it triggers preemption)
        """
        commands = [["scancel", f"{self.job_id}", f"--signal={x}"] for x in ["USR1", "SIGTERM"]]
        if not timeout:  # in case of preemption, SIGTERM is sent first
            subprocess.check_call(commands[1], shell=False)
        subprocess.check_call(commands[0], shell=False)


class SlurmExecutor(_core.PicklingExecutor):
    """Slurm job executor
    This class is used to hold the parameters to run a job on slurm.
    In practice, it will create a batch file in the specified directory for each job,
    and pickle the task function and parameters. At completion, the job will also pickle
    the output. Logs are also dumped in the same directory.

    Parameters
    ----------
    folder: Path/str
        folder for storing job submission/output and logs.
    max_num_timeout: int
        Maximum number of time the job can be requeued after timeout (if
        the instance is derived from helpers.Checkpointable)

    Note
    ----
    - be aware that the log/output folder will be full of logs and pickled objects very fast,
      it may need cleaning.
    - the folder needs to point to a directory shared through the cluster. This is typically
      not the case for your tmp! If you try to use it, slurm will fail silently (since it
      will not even be able to log stderr.
    - use update_parameters to specify custom parameters (n_gpus etc...). If you
      input erroneous parameters, an error will print all parameters available for you.
    """

    job_class = SlurmJob

    def __init__(self, folder: Union[Path, str], max_num_timeout: int = 3) -> None:
        super().__init__(folder, max_num_timeout)
        if shutil.which("srun") is None:
            raise RuntimeError('Could not detect "srun", are you indeed on a slurm cluster?')

    def update_parameters(self, **kwargs: Any) -> None:
        """Updates sbatch submission file parameters

        Parameters
        ----------
        See slurm documentation for most parameters.
        Most useful parameters are: time, mem, num_gpus, cpus_per_task, partition
        Below are the parameters that differ from slurm documentation:

        signal_delay_s: int
            delay between the kill signal and the actual kill of the slurm job.
        setup: list
            a list of command to run in sbatch befure running srun
        num_gpus: int
            number of gpus required by the job
        array_parallelism: int
            number of map tasks that will be executed in parallel

        Raises
        ------
        ValueError
            In case an erroneous keyword argument is added, a list of all eligible parameters
            is printed, with their default values

        Note
        ----
        Best practice (as far as Quip is concerned): num_cpus=2x (number of data workers + num_gpus)
        """
        defaults = _get_default_parameters()
        invalid_parameters = sorted(set(kwargs) - set(defaults))
        if invalid_parameters:
            string = "\n  - ".join(f"{x} (default: {repr(y)})" for x, y in sorted(defaults.items()))
            raise ValueError(
                f"Unavailable parameter(s): {invalid_parameters}\nValid parameters are:\n  - {string}"
            )
        # check that new parameters are correct
        _make_sbatch_string(command="nothing to do", folder=self.folder, **kwargs)
        super().update_parameters(**kwargs)

    def valid_parameters(self) -> Set[str]:
        """Parameters that can be set through update_parameters
        """
        return set(_get_default_parameters())

    def map_array(  # pylint: disable=too-many-locals
        self, fn: Callable[..., R], *iterable: Iterable[Any]
    ) -> List[_core.Job[R]]:
        """A distributed equivalent of the map() built-in function
        Use the `array_parallelism` parameter of `executor.update_parameters`
        To control how many jobs can run in parallel.

        Parameters
        ----------
        fn: callable
            function to compute
        *iterable: Iterable
            lists of arguments that are passed as arguments to fn.

        Returns
        -------
        List[Job]
            A list of Job instances.

        Example
        -------
        a = [1, 2, 3]
        b = [10, 20, 30]
        executor.submit(add, a, b)
        # jobs will compute 1 + 10, 2 + 20, 3 + 30
        """
        folder = utils.JobPaths.get_first_id_independent_folder(self.folder)
        folder.mkdir(parents=True, exist_ok=True)
        pickle_paths = []

        delayed = []
        for args in zip(*iterable):
            pickle_path = folder / f"{uuid.uuid4().hex}.pkl"
            d = utils.DelayedSubmission(fn, *args)
            d.timeout_countdown = self.max_num_timeout
            d.dump(pickle_path)
            pickle_paths.append(pickle_path)
            delayed.append(d)

        n = len(delayed)
        # Make a copy of the executor, since we don't want other jobs to be
        # scheduled as arrays.
        array_ex = SlurmExecutor(self.folder, self.max_num_timeout)
        array_ex.update_parameters(**self.parameters)
        array_ex.parameters["map_count"] = n
        self.throttle()

        first_job: _core.Job[R] = array_ex._submit_command(self._submitit_command_str)
        tasks_ids = list(range(first_job.num_tasks))
        jobs: List[_core.Job[R]] = [
            SlurmJob(folder=self.folder, job_id=f"{first_job.job_id}_{a}", tasks=tasks_ids) for a in range(n)
        ]
        for job, pickle_path in zip(jobs, pickle_paths):
            job.paths.move_temporary_file(pickle_path, "submitted_pickle")
        return jobs

    @property
    def _submitit_command_str(self) -> str:
        # make sure to use the current executable (required in pycharm)
        return f"{sys.executable} -u -m submitit._submit '{self.folder}'"

    def _make_submission_file_text(self, command: str, uid: str) -> str:
        return _make_sbatch_string(command=command, folder=self.folder, **self.parameters)

    def _num_tasks(self) -> int:
        nodes: int = self.parameters.get("nodes", 1)
        tasks_per_node: int = self.parameters.get("ntasks_per_node", 1)
        return nodes * tasks_per_node

    def _make_submission_command(self, submission_file_path: Path) -> List[str]:
        return ["sbatch", str(submission_file_path)]

    @staticmethod
    def _get_job_id_from_submission_command(string: Union[bytes, str]) -> str:
        """Returns the job ID from the output of sbatch string
        """
        if not isinstance(string, str):
            string = string.decode()
        output = re.search(r"job (?P<id>[0-9]+)", string)
        if output is None:
            raise utils.FailedSubmissionError(
                'Could not make sense of sbatch output "{}"\n'.format(string)
                + "Job instance will not be able to fetch status\n"
                "(you may however set the job job_id manually if needed)"
            )
        return output.group("id")


class PatternReader:
    """Splits the sacct output line given the pattern line (the one with dashes)
    """

    def __init__(self, pattern: str) -> None:
        assert set(pattern) == {" ", "-"}
        self.pattern = pattern

    def split(self, line: str) -> List[str]:
        columns: List[Optional[int]] = [0]
        columns += [i for i, c in enumerate(self.pattern) if c == " "]
        columns += [None]
        return [line[start:end].strip() for start, end in zip(columns[:-1], columns[1:])]


def _get_default_parameters() -> Dict[str, Any]:
    """Parameters that can be set through update_parameters
    """
    specs = inspect.getfullargspec(_make_sbatch_string)
    zipped = zip(specs.args[-len(specs.defaults) :], specs.defaults)
    return {key: val for key, val in zipped if key not in {"command", "folder", "map_count"}}


# pylint: disable=too-many-arguments,unused-argument, too-many-locals
def _make_sbatch_string(
    command: str,
    folder: Union[str, Path],
    job_name: str = "submitit",
    partition: str = "learnfair",
    time: int = 5,
    nodes: int = 1,
    ntasks_per_node: int = 1,
    num_gpus: Optional[int] = None,
    cpus_per_task: int = 1,
    setup: Optional[List[str]] = None,
    mem: str = "64GB",
    signal_delay_s: int = 90,
    gres: str = "",
    comment: str = "",
    constraint: str = "",
    exclude: str = "",
    array_parallelism: int = 256,
    map_count: Optional[int] = None,  # used internally
    additional_parameters: Optional[Dict[str, Any]] = None,
) -> str:
    """Creates the content of an sbatch file with provided parameters

    Parameters
    ----------
    See slurm documentation for most parameters.
    Below are the parameters that differ from slurm documentation:

    folder: str/Path
        folder where print logs and error logs will be written
    signal_delay_s: int
        delay between the kill signal and the actual kill of the slurm job.
    setup: list
        a list of command to run in sbatch befure running srun
    num_gpus: int
        number of gpus required by the job
    map_size: int
        number of simultaneous map/array jobs allowed
    additional_parameters: dict
        Forces any parameter to a given value in sbatch. This can be useful
        to add parameters which are not currently available in submitit.
        Eg: {"mail-user": "blublu@fb.com", "mail-type": "BEGIN"}

    Raises
    ------
    ValueError
        In case an erroneous keyword argument is added, a list of all eligible parameters
        is printed, with their default values
    """
    nonslurm = ["nonslurm", "folder", "command", "map_count", "array_parallelism", "additional_parameters"]
    parameters = {x: y for x, y in locals().items() if y and y is not None and x not in nonslurm}
    # rename and reformat parameters
    parameters["signal"] = signal_delay_s
    del parameters["signal_delay_s"]
    if job_name:
        parameters["job_name"] = utils.sanitize(job_name)
    if comment:
        parameters["comment"] = utils.sanitize(comment, only_alphanum=False)
    if num_gpus is not None:
        if gres:
            raise ValueError("Cannot specify both 'num_gpus' and 'gres', pick one!")
        if "num_gpus" in parameters:  # may have been already removed if num_gpus=0
            del parameters["num_gpus"]
            parameters["gres"] = f"gpu:{num_gpus}"
    # add necessary parameters
    paths = utils.JobPaths(folder=folder)
    stdout = str(paths.stdout)
    stderr = str(paths.stderr)
    # Job arrays will write files in the form  <ARRAY_ID>_<ARRAY_TASK_ID>_<TASK_ID>
    if map_count is not None:
        assert isinstance(map_count, int) and map_count
        parameters["array"] = f"0-{map_count - 1}%{min(map_count, array_parallelism)}"
        stdout = stdout.replace("%j", "%A_%a")
        stderr = stderr.replace("%j", "%A_%a")
    parameters["output"] = stdout.replace("%t", "0")
    parameters["error"] = stderr.replace("%t", "0")
    parameters.update({"signal": f"USR1@{signal_delay_s}", "open-mode": "append"})
    if additional_parameters is not None:
        parameters.update(additional_parameters)
    # now create
    lines = ["#!/bin/bash", "", "# Parameters"]
    lines += ["#SBATCH --{}={}".format(x.replace("_", "-"), parameters[x]) for x in sorted(parameters)]
    # environment setup:
    if setup is not None:
        lines += ["", "# setup"] + setup
    # commandline (this will run the function and args specified in the file provided as argument)
    # We pass --output and --error here, because the SBATCH command doesn't work as expected with a filename pattern
    lines += ["", "# command", f"srun --output '{stdout}' --error '{stderr}' --unbuffered {command}"]
    return "\n".join(lines)
