import tempfile
from pathlib import Path

from . import helpers, utils


def _three_time(x: int) -> int:
    return 3 * x


def test_function_sequence_checkpoint() -> None:
    with tempfile.TemporaryDirectory() as folder:
        filepath = Path(folder) / "test_funcseq.pkl"
        fs0 = helpers.FunctionSequence(verbose=True)
        fs0.add(_three_time, 4)
        fs0.add(_three_time, 5)
        assert len(fs0) == 2
        assert sum(x.done() for x in fs0) == 0
        utils.cloudpickle_dump(fs0, filepath)
        fs1 = utils.pickle_load(filepath)
        assert sum(x.done() for x in fs1) == 0
        assert fs1() == [12, 15]
        assert sum(x.done() for x in fs1) == 2
