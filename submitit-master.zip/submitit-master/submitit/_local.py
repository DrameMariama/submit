import argparse
from pathlib import Path

from .local import Controller

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run a job")
    parser.add_argument("folder", type=Path, help="Folder where the jobs are stored (in subfolder)")
    args_ = parser.parse_args()
    controller = Controller(args_.folder)
    controller.run(max_requeue=6)  # safety measure :)
