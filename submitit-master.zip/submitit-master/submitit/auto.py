import shutil
import warnings
from pathlib import Path
from typing import Any, Callable, Dict, Iterable, List, Optional, Union

from . import chronos, debug, local, slurm
from ._core import Executor, Job, R


def _make_equivalence_dict(name: str) -> Dict[str, str]:
    """Returns a dict of type {shared_name: <cluster>_name}
    for either slurm or chronos
    """
    if name in ("debug", "local"):
        return {}
    equivalence = {
        "name": ("job_name", "name"),
        "timeout_min": ("time", "timeout"),
        "mem_gb": ("mem", "mem"),
        "nodes": ("nodes", "gang_size"),  # gang-size,
        "cpus_per_task": ("cpus_per_task", "cpu"),
        "gpus_per_node": ("num_gpus", "gpu"),
        "tasks_per_node": ("ntasks_per_node", "ntasks_per_node"),
    }
    index = ["slurm", "chronos"].index(name)
    return {x: y[index] for x, y in equivalence.items()}


class AutoExecutor(Executor):
    """Automatic job executor
    This class is used to hold the parameters to run a job either on Slurm or on
    Chronos, depending on the environment.
    It can also be used to run job locally or in debug mode.
    In practice, it will create a bash file in the specified directory for each job,
    and pickle the task function and parameters. At completion, the job will also pickle
    the output. Logs are also dumped in the same directory.

    For Chronos only:
    - If you run a par file, it will copy it on the cluster machine and run with it.
    Otherwise, it will create an archive from the currently active conda env, and copy it
    to the cluster machine.
    - If you want to persist the archive of the conda env, you can specify it with `conda_file`.
    - After instantiation, you can specify folders to upload to the job environment with
    `register_dev_folders`.

    Parameters
    ----------
    folder: Path/str
        folder for storing job submission/output and logs.
    max_num_timeout: int (slurm)
        Maximum number of time the job can be requeued after timeout (if
        the instance is derived from helpers.Checkpointable)
    warn_ignored: bool
        prints a warning each time a parameter is provided but ignored because it is only
        useful for the other cluster.
    conda_file: Path/str (chronos)
        Used to persist the archive of the conda environment.
        If provided, uses this conda environment, instead of zipping the current env.
        If provided, but the file doesn't exist, we will zip the current env, and copy it
        to this location.
    cluster: str
        Forces AutoExecutor to use the given environment. Use "local" to run jobs locally,
        "debug" to run jobs in process.
    Note
    ----
    - be aware that the log/output folder will be full of logs and pickled objects very fast,
      it may need cleaning.
    - use update_parameters to specify custom parameters (gpus_per_node etc...). If you
      input erroneous parameters, an error will print all parameters available for you.
    """

    def __init__(  # pylint: disable-msg=too-many-arguments
        self,
        folder: Union[str, Path],
        max_num_timeout: int = 3,
        warn_ignored: bool = True,
        conda_file: Union[str, Path, None] = None,
        cluster: Optional[str] = None,
    ) -> None:
        self.cluster = cluster or self.which()
        if self.cluster == "slurm":
            self._executor: Executor = slurm.SlurmExecutor(folder, max_num_timeout=max_num_timeout)
        elif self.cluster == "chronos":
            self._executor = chronos.ChronosExecutor(folder, conda_file=conda_file)
        elif self.cluster == "local":
            self._executor = local.LocalExecutor(
                folder, max_num_timeout=max_num_timeout, warn_ignored=warn_ignored, conda_file=conda_file
            )
        elif self.cluster == "debug":
            self._executor = debug.DebugExecutor(folder)
        else:
            raise ValueError(f"AutoExecutor doesn't know any executor named {self.cluster}")

        super().__init__(self._executor.folder, self._executor.parameters)
        self.warn_ignored = warn_ignored

        # prepare conversion
        self._replacer: Dict[str, str] = _make_equivalence_dict(self.cluster)
        # parameters for which the shared name must be used
        self._forbidden_params = {
            x for cltr in ["slurm", "chronos"] for x in _make_equivalence_dict(cltr).values()
        } - set(self._replacer)
        if self.cluster in ("local", "debug"):
            self._forbidden_params = set()
        # parameters that are used by the other executor, and should be ignored
        if self.cluster == "slurm":  # for chronos valid params are in a global variable
            self._ignored_params = {x.replace("-", "_") for x in chronos.VALID_KEYS}
            if conda_file is not None:
                warnings.warn(f"Ignoring conda_file: {conda_file}")
        else:  # for slurm, they are most of the arguments of the _make_sbatch_string function
            self._ignored_params = set(slurm._get_default_parameters())
        self._ignored_params -= set(self._replacer) | self._forbidden_params

    @staticmethod
    def which() -> str:
        """Returns what is the detected cluster."""
        if shutil.which("srun") is not None:
            return "slurm"
        elif shutil.which("crun") is not None:
            return "chronos"
        else:
            raise RuntimeError("Did not detect either slurm or chronos")

    def register_dev_folders(self, folders: List[Union[str, Path]]) -> None:
        """Archive a list of folders to be untarred in the job working directory.
        This is only implemented for chronos, for running job on non-installed packages.
        This is not useful on slurm since the working directory of jobs is identical to
        your work station working directory.

        folders: list of paths
            The list of folders to archive and untar in the job working directory
        """
        if isinstance(self._executor, chronos.ChronosExecutor):
            self._executor.register_dev_folders(folders)
        elif self.warn_ignored:
            warnings.warn("Ignoring dev folder registration as it is only supported (and needed) for Chronos")

    def update_parameters(self, **kwargs: Any) -> None:
        """Updates submission parameters to srun/crun.

        Parameters
        ----------
        See specific Executor for documentation.
        Shared parameters are: timeout_min (int), mem_gb (int), gpus_per_node (int), cpus_per_task (int),
        nodes (int), tasks_per_node (int) and name (str).

        Notes
        -----
        - Shared parameters replace some cluster specific parameters which are now forbidden.
        - Parameters which are specific to the cluster you are not using will be ignored.
        - Parameters which do not exist will trigger an error listing all available parameters. (eg: executor.update_parameters(blublu=12))
        """

        # check type of replaced variables
        for name in self._replacer:
            if name in kwargs:
                expected_type = int if name != "name" else str
                assert isinstance(kwargs[name], expected_type), (
                    f'Parameter "{name}" expected type {expected_type} ' f'(but value: "{kwargs[name]}")'
                )
        if "gres" in kwargs:
            raise RuntimeError(
                "'gres' parameter is only allowed to be used directly on 'SlurmExecutor' (not through 'AutoExecutor')"
            )
        # check no forbidden parameters
        forbidden = set(kwargs) & self._forbidden_params
        if forbidden:
            message = "\n - ".join([f'"{y}" -> "{x}"' for x, y in self._replacer.items() if y in forbidden])
            raise NameError(
                f"Parameter(s) should be replaced with shared name "
                f"(beware, type and unit may change):\n - {message}"
            )
        # replace names and ignore parameteters from other
        ignored = {x for x in kwargs if x in self._ignored_params}
        if self.warn_ignored and ignored:
            warnings.warn(
                "The following set of parameters are ignored as they are only available for the other cluster:\n"
                f"{ignored}"
            )
        parameters = {self._replacer.get(x, x): y for x, y in kwargs.items() if x not in self._ignored_params}
        # replace type in some cases
        if self.cluster == "slurm" and "mem" in parameters:
            parameters["mem"] = "{}GB".format(parameters["mem"])
        if self.cluster == "chronos" and "timeout" in parameters:
            # timeout is in minutes, crun expects in seconds
            parameters["timeout"] *= 60
        if self.cluster == "chronos" and "cpu" in parameters:
            # provided as "cpus_per_task", but "cpus" is per node in crun
            nt = "ntasks_per_node"
            task_per_node = parameters.get(nt, self._executor.parameters.get(nt, 1))
            parameters["cpu"] = parameters["cpu"] * task_per_node
        # update parameters in the core executor
        try:
            self._executor.update_parameters(**parameters)
        except ValueError as e:
            conversion = "\n - ".join([f'"{y}" -> "{x}"' for x, y in self._replacer.items()])
            print(
                "Wrong parameters. See executor specific parameters below, "
                f"with the following conversion in mind:\n - {conversion}"
            )
            raise e

    def submit(self, fn: Callable[..., R], *args: Any, **kwargs: Any) -> Job[R]:
        return self._executor.submit(fn, *args, **kwargs)

    def map_array(self, fn: Callable[..., R], *iterable: Iterable[Any]) -> List[Job[R]]:
        return self._executor.map_array(fn, *iterable)
