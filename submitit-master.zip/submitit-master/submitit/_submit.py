from .submission import submitit_main

if __name__ == "__main__":
    # This script is called by Executor.submit
    submitit_main()
