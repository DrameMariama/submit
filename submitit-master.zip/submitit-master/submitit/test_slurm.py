import contextlib
import os
import signal
import tempfile
from pathlib import Path
from typing import Any, Iterator
from unittest.mock import patch

import pytest

from . import helpers, slurm, submission, test_core, utils


def _mock_log_files(job: slurm._core.Job[Any], prints: str = "", errors: str = "") -> None:
    """Write fake log files
    """
    filepaths = [str(x).replace("%j", str(job.job_id)) for x in [job.paths.stdout, job.paths.stderr]]
    for filepath, msg in zip(filepaths, (prints, errors)):
        with Path(filepath).open("w") as f:
            f.write(msg)


@contextlib.contextmanager
def mocked_slurm(state: str = "RUNNING", job_id: str = "12", array: int = 0) -> Iterator[str]:
    with contextlib.ExitStack() as stack:
        stack.enter_context(
            test_core.MockedSubprocess(state=state, job_id=job_id, shutil_which="srun", array=array).context()
        )
        stack.enter_context(
            utils.environment_variables(**{"_USELESS_TEST_ENV_VAR_": "1", "SLURM_JOB_ID": f"{job_id}"})
        )
        tmp = stack.enter_context(tempfile.TemporaryDirectory())
        yield tmp


def test_mocked_missing_state() -> None:
    with mocked_slurm(state="       ", job_id="12") as tmp:
        job: slurm.SlurmJob[None] = slurm.SlurmJob(tmp, "12")
        assert job.state == "UNKNOWN"
        job._send_requeue_signal(timeout=False)  # check_call is bypassed by MockedSubprocess


def test_job_environment() -> None:
    with mocked_slurm(job_id="12"):
        print(utils.JobEnvironment())


def test_slurm_job_mocked() -> None:
    with mocked_slurm() as tmp:
        executor = slurm.SlurmExecutor(folder=tmp)
        job = executor.submit(test_core.do_nothing, 1, 2, blublu=3)
        assert job.job_id == "12"
        assert job.state == "RUNNING"
        assert job.stdout() is None
        _mock_log_files(job, errors="This is the error log\n", prints="hop")
        job._results_timeout_s = 0
        with pytest.raises(utils.UncompletedJobError):
            job._get_outcome_and_result()
        _mock_log_files(job, errors="This is the error log\n", prints="hop")
        submission.process_job(job.paths.folder)
        assert job.result() == 12
        # logs
        assert job.stdout() == "hop"
        assert job.stderr() == "This is the error log\n"
    assert "_USELESS_TEST_ENV_VAR_" not in os.environ, "Test context manager seems to be failing"


def test_slurm_job_array_mocked() -> None:
    n = 5
    with mocked_slurm(array=n) as tmp:
        executor = slurm.SlurmExecutor(folder=tmp)
        executor.update_parameters(array_parallelism=3)
        data1, data2 = range(n), range(10, 10 + n)

        def add(x: int, y: int) -> int:
            assert x in data1
            assert y in data2
            return x + y

        jobs = executor.map_array(add, data1, data2)
        array_id = jobs[0].job_id.split("_")[0]
        assert [f"{array_id}_{a}" for a in range(n)] == [j.job_id for j in jobs]

        for job in jobs:
            os.environ["SLURM_JOB_ID"] = str(job.job_id)
            submission.process_job(job.paths.folder)
        assert list(map(add, data1, data2)) == [j.result() for j in jobs]
        # check submission file
        sbatch = slurm._core.Job(tmp, job_id=array_id).paths.submission_file.read_text()
        array_line = [l.strip() for l in sbatch.splitlines() if "array" in l]
        assert array_line == ["#SBATCH --array=0-4%3"]


def test_slurm_error_mocked() -> None:
    with mocked_slurm() as tmp:
        executor = slurm.SlurmExecutor(folder=tmp)
        executor.update_parameters(time=24, num_gpus=0)  # just to cover the function
        job = executor.submit(test_core.do_nothing, 1, 2, error=12)
        with pytest.raises(ValueError):
            submission.process_job(job.paths.folder)
        _mock_log_files(job, errors="This is the error log\n")
        with pytest.raises(utils.FailedJobError):
            job.result()
        exception = job.exception()
        assert isinstance(exception, utils.FailedJobError)


def test_signal(tmp_path: Path) -> None:
    with utils.environment_variables(_TEST_CLUSTER_="slurm"):
        job_paths = utils.JobPaths(tmp_path, "1234")
        fs0 = helpers.FunctionSequence()
        fs0.add(test_core._three_time, 4)
        fs0.delayed_functions[0].dump(job_paths.submitted_pickle)  # hack to create a file
        sig = submission.SignalHandler(job_paths, utils.DelayedSubmission(fs0))
        sig.sigterm(signum=signal.Signals.SIGUSR1, frame=None)  # type: ignore
        with patch("submitit.submission._exit", return_value=None), patch(
            "submitit.submission._slurm_requeue", return_value=None
        ):
            sig.sigusr1(signum=signal.Signals.SIGUSR1, frame=None)  # type: ignore
        resubmitted = utils.DelayedSubmission.load(job_paths.submitted_pickle)
        output = resubmitted.result()
        assert output == [12]


def test_make_batch_string() -> None:
    string = slurm._make_sbatch_string(command="blublu", folder="/tmp", additional_parameters=dict(blublu=12))
    assert "partition" in string
    assert "--command" not in string
    assert "constraint" not in string
    record_file = Path(__file__).parent / "_sbatch_test_record.txt"
    if not record_file.exists():
        record_file.write_text(string)
    recorded = record_file.read_text()
    changes = []
    for k, (line1, line2) in enumerate(zip(string.splitlines(), recorded.splitlines())):
        if line1 != line2:
            changes.append(f'line #{k + 1}: "{line2}" -> "{line1}"')
    if changes:
        print(string)
        print("# # # # #")
        print(recorded)
        message = ["Difference with reference file:"] + changes
        message += ["", "Delete the record file if this is normal:", f"rm {record_file}"]
        raise AssertionError("\n".join(message))


def test_make_batch_string_gpu() -> None:
    string = slurm._make_sbatch_string(command="blublu", folder="/tmp", num_gpus=2)
    assert "--gres=gpu:2" in string
    string = slurm._make_sbatch_string(command="blublu", folder="/tmp", gres="blublu:2")
    assert "--gres=blublu:2" in string
    with pytest.raises(ValueError):
        slurm._make_sbatch_string(command="blublu", folder="/tmp", num_gpus=0, gres="blublu:2")


def test_update_parameters_error() -> None:
    with mocked_slurm() as tmp:
        with pytest.raises(ValueError):
            executor = slurm.SlurmExecutor(folder=tmp)
            executor.update_parameters(blublu=12)


def test_read_info() -> None:
    example = """
       JobID    JobName  Partition    Account  AllocCPUS      State ExitCode
------------ ---------- ---------- ---------- ---------- ---------- --------
5610980             job  learnfair  fairusers          1    RUNNING      0:0
5610980.ext+     extern             fairusers          1    RUNNING      0:0
5610980.0        python             fairusers          1    RUNNING      0:0
""".lstrip(
        "\n"
    )
    output = slurm.SlurmInfoWatcher().read_info(example)["5610980"]
    assert output == {
        "JobID": "5610980",
        "JobName": "job",
        "Partition": "learnfair",
        "Account": "fairusers",
        "AllocCPUS": "1",
        "State": "RUNNING",
        "ExitCode": "0:0",
    }


@pytest.mark.parametrize(  # type: ignore
    "name,state", [("12_0", "R"), ("12_1", "U"), ("12_2", "X"), ("12_3", "U"), ("12_4", "X")]
)
def test_read_info_array(name: str, state: str) -> None:
    example = """
       JobID      State
------------ ----------
12_0                  R
12_[2+                X
""".lstrip(
        "\n"
    )
    watcher = slurm.SlurmInfoWatcher()
    for jobid in ["12_2", "12_4"]:
        watcher.register_job(jobid)
    output = watcher.read_info(example)
    assert output.get(name, {}).get("State", "U") == state


@pytest.mark.parametrize(  # type: ignore
    "string,expected",
    [(b"Submitted batch job 5610208\n", "5610208"), ("Submitted batch job 5610208\n", "5610208")],
)
def test_get_id_from_submission_command(string: str, expected: int) -> None:
    output = slurm.SlurmExecutor._get_job_id_from_submission_command(string)
    assert output == expected


def test_get_id_from_submission_command_raise() -> None:
    with pytest.raises(utils.FailedSubmissionError):
        slurm.SlurmExecutor._get_job_id_from_submission_command(string=b"blublu")


def test_watcher() -> None:
    with mocked_slurm():
        watcher = slurm.SlurmInfoWatcher()
        assert watcher.num_calls == 0
        with pytest.warns(UserWarning):
            state = watcher.get_state(job_id="11")
        assert state == "UNKNOWN"
        assert set(watcher._info_dict.keys()) == {"12"}
        watcher.clear()
        assert watcher._registered == {"11"}


def test_get_default_parameters() -> None:
    defaults = slurm._get_default_parameters()
    assert defaults["cpus_per_task"] == 1
    assert defaults["mem"] == "64GB"
