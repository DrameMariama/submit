from pathlib import Path

from . import debug


def test_debug_job(tmp_path: Path) -> None:
    def func(p: int) -> int:
        return 2 * p

    executor = debug.DebugExecutor(tmp_path)
    job = executor.submit(func, 4)
    assert job.result() == 8


def test_debug_job_array(tmp_path: Path) -> None:
    n = 5
    data1, data2 = range(n), range(10, 10 + n)

    def f(x: int, y: int) -> int:
        assert x in data1
        assert y in data2
        return x + y

    executor = debug.DebugExecutor(tmp_path)
    jobs = executor.map_array(f, data1, data2)

    assert list(map(f, data1, data2)) == [j.result() for j in jobs]


def test_debug_error(tmp_path: Path) -> None:
    def failing_job() -> None:
        raise Exception("Failed on purpose")

    executor = debug.DebugExecutor(tmp_path)
    job = executor.submit(failing_job)
    exception = job.exception()
    assert isinstance(exception, Exception)
    message = exception.args[0]
    assert "Failed on purpose" in message
