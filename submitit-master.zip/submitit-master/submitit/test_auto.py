from pathlib import Path

import pytest

from . import auto, test_chronos, test_slurm


def test_slurm_executor() -> None:
    with test_slurm.mocked_slurm():
        executor = auto.AutoExecutor(folder=".")
    assert executor.cluster == "slurm"
    with pytest.warns(UserWarning):
        executor.update_parameters(mem_gb=2, name="machin", host_filter="blublu")  # host_filter is ignored
    params = executor._executor.parameters
    assert params == {"mem": "2GB", "job_name": "machin"}
    # shared parameter with wrong type
    with pytest.raises(AssertionError):
        executor.update_parameters(mem_gb=2.0)  # should be int
    with pytest.raises(ValueError):
        executor.update_parameters(blublu=2.0)
    with pytest.raises(RuntimeError):
        executor.update_parameters(gres="blublu")


def test_chronos_executor() -> None:
    with test_chronos.mocked_chronos() as tmp:
        executor = auto.AutoExecutor(folder=tmp)
        assert executor.cluster == "chronos"
        with pytest.warns(UserWarning):
            executor.update_parameters(
                timeout_min=2, cpus_per_task=2, partition="dev"
            )  # partition is ignored
        executor.register_dev_folders([Path(__file__).parent])
        params = executor._executor.parameters
        assert params == {"timeout": 120, "cpu": 2}
        # parameter with changed name
        with pytest.raises(NameError):
            executor.update_parameters(timeout=2)
        del executor  # delete before end of context to avoid warning of tmp_dir not existing anymore
