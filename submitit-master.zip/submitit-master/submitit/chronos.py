import os
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from . import _core, utils

VALID_KEYS = {
    "cluster",
    "name",
    "hostgroup",
    "retries",
    "timeout",
    "mailwhen",
    "gang-size",
    "gang-rack-affinity",
    "gpu",
    "cpu",
    "mem",
    "host-filter",
    "ntasks-per-node",
    "secure-group",
}

_ENVDIR = "/tmp/_submitit_env_dir_"  # where the conda env is unpacked


class ChronosInfoWatcher(_core.InfoWatcher):
    # pylint: disable=too-many-instance-attributes

    def _make_command(self) -> Optional[List[str]]:
        to_check = self._registered - self._finished
        if not to_check:
            return None
        return ["cinfo", "--jobId", "--jobState", "--show-key"] + [str(jid) for jid in to_check]

    def get_state(self, job_id: str, mode: str = "standard") -> str:
        """Returns the state of the job
        State of finished jobs are cached (use watcher.clear() to remove all cache)

        Parameters
        ----------
        job_id: int
            id of the job on the cluster
        mode: str
            one of "force" (forces a call), "standard" (calls regularly) or "cache" (does not call)
        """
        info = self.get_info(job_id, mode=mode)
        state = info.get("jobState", "")
        return state if state else "UNKNOWN"

    def read_info(self, string: Union[bytes, str]) -> Dict[str, Dict[str, str]]:
        if not isinstance(string, str):
            string = string.decode()
        all_info = (read_cinfo(line) for line in string.splitlines())
        return {info["jobId"]: info for info in all_info}


def read_cinfo(string: Union[bytes, str]) -> Dict[str, str]:
    """Reads the output of cinfo and returns a dictionary containing main information
    """
    if not isinstance(string, str):
        string = string.decode()
    stats = {}
    for keyval in string.split("\t"):
        keyval = keyval[1:-1]  # remove parenthesis
        key, val = keyval.split(",")
        stats[key] = val
    return stats


class ChronosJob(_core.Job[_core.R]):

    _cancel_command = "ckill"
    # longer timeout, because consistency is not guaranteed on Gluster
    _results_timeout_s = 90
    watcher = ChronosInfoWatcher()


class ChronosExecutor(_core.PicklingExecutor):
    # pylint: disable=too-many-instance-attributes
    """Chronos job executor
    This class is used to hold the parameters to run a job with crun.
    In practice, it will create a bash file in the specified directory for each job,
    and pickle the task function and parameters. At completion, the job will also pickle
    the output. Logs are also dumped in the same directory.

    If you want to persist the archive of the conda env, you can specify it with `conda_file`.
    If you run a par file, it will copy it on the cluster machine and run with it.
    Otherwise, it will create an archive from the currently active conda env, and copy it
    to the cluster machine.

    Parameters
    ----------
    folder: Path/str
        folder for storing job submission/output and logs.
    conda_file: Path/str
        Used to persist the archive of the conda environment.
        If provided, uses this conda environment, instead of zipping the current env.
        If provided, but the file doesn't exist, we will zip the current env, and copy it
        to this location.

    Note
    ----
    - be aware that the log/output folder will be full of logs and pickled objects very fast,
      it may need cleaning.
    - use update_parameters to specify custom parameters (gpu etc...). If you
      input erroneous parameters, an error will print all parameters available for you.
    """

    job_class = ChronosJob

    def __init__(self, folder: Union[Path, str], conda_file: Optional[Union[str, Path]] = None) -> None:
        super().__init__(folder)
        self._throttling = 0.0
        utils.check_shared_folder(self.folder)
        # preliminary check
        if shutil.which("crun") is None:
            raise RuntimeError('Could not detect "crun". Checkout submitit README for install instructions.')
        self.conda_env = None
        self.xar_file = None
        self.par_file = None
        indep_folder = utils.JobPaths.get_first_id_independent_folder(self.folder)
        indep_folder.mkdir(parents=True, exist_ok=True)
        self._executor_dir = tempfile.mkdtemp(prefix="executor_", dir=str(indep_folder))
        # If this runs from a xar or a par file, use it instead of the conda env.
        xar_file = os.environ.get("FB_XAR_INVOKED_NAME")
        par_file = os.environ.get("FB_PAR_FILENAME")
        if xar_file:
            self.xar_file = utils.copy_par_file(xar_file, self._executor_dir)
        elif par_file:
            self.par_file = utils.copy_par_file(par_file, self._executor_dir)
        else:
            # Conda env management
            if not conda_file:
                self.conda_env = utils.package_conda_env(self._executor_dir)
            else:
                utils.check_shared_folder(conda_file)
                if not Path(conda_file).exists():
                    tmp_conda = utils.package_conda_env(self._executor_dir)
                    shutil.move(str(tmp_conda), conda_file)
                self.conda_env = Path(conda_file)
        # compact dev folders into a tar.gz file
        self.dev_archive: Optional[Path] = None
        self._set_executor_permissions()
        self._environ: Dict[str, str] = {}

    def register_dev_folders(self, folders: List[Union[str, Path]]) -> None:
        """Archive a list of folders to be untarred in the job working directory

        folders: list of paths
            The list of folders to archive and untar in the job working directory
        """
        self.dev_archive = None
        if folders:
            self.dev_archive = Path(self._executor_dir) / "_dev_archive_.tar.gz"
            utils.archive_dev_folders(folders, self.dev_archive)
            self._set_executor_permissions()

    def update_parameters(self, **kwargs: Any) -> None:
        """Creates or update a batch file with provided parameters

        Parameters
        ----------
        See crun documentation for most parameters.
        https://our.internmc.facebook.com/intern/wiki/Chronos-c-binaries/crun/

        Most useful parameters are: gpu, cpu, mem

        You need to replace `-` with `_` in the name of arguments (otherwise, Python is not happy)
        eg, use update_parameters(gang_size=2) instead of `gang-size`

        To set jobs environment variables, you can provide the parameter 'environ' (Dict[str, str] expected)
        It should be a dict of environment variables and their values that needs to be set for the job execution.

        Raises
        ------
        ValueError
            In case an erroneous keyword argument is added, a list of all eligible parameters
            is printed, with their default values

        Note
        ----
        Best practice (as far as Quip is concerned): num_cpus=2x (number of data workers + num_gpus)
        The gang-size parameter MUST not be used for now: the current version doesn't work with
        multi-nodes jobs (even gang-size=1 will not work, as it produces a multi-nodes job, with 1 node)
        """
        self._environ = kwargs.pop("environ", {})
        self.parameters = {
            x: y for x, y in self.parameters.items() if x in VALID_KEYS
        }  # clean previously erroneous params
        super().update_parameters(**kwargs)
        self._make_submission_command(Path(__file__))

    def _num_tasks(self) -> int:
        nodes: int = self.parameters.get("gang_size", 1)
        tasks_per_node: int = self.parameters.get("ntasks_per_node", 1)
        return nodes * tasks_per_node

    # pylint: disable=R0914
    @property
    def _submitit_command_str(self) -> str:
        """
        Submit several python processes (one per task) on each node.

        The command set several environment variables, redirect stdout and stderr for each task
        and wait for all tasks to finish.

        The job id of the parent ($CHRONOS_PARENT_JOB_ID) is read in the script.
        CHRONOS_NTASKS_PER_NODE and CHRONOS_JOB_NUM_NODES are the same for all tasks.
        CHRONOS_LOCALID is different for each task.

        Log filenames follow the pattern in ``JobPaths``.
        """
        num_tasks_per_node = self.parameters.get("ntasks_per_node", 1)
        num_nodes = self.parameters.get("gang_size", 1)
        task_commands = []
        paths = utils.JobPaths(folder=self.folder)

        if self.conda_env:
            # Python command using the conda env
            run_python = f"{_ENVDIR}/bin/python -u -m submitit._submit '{self.folder}'"
        elif self.par_file or self.xar_file:
            # Python command used in par file
            python_bin = sys.executable
            # We will unzip the par file in _ENVDIR
            run_python = (
                f"PYTHONPATH={_ENVDIR} PYTHONUNBUFFERED=1 {python_bin} -m submitit._submit '{self.folder}'"
            )

        for local_task_id in range(num_tasks_per_node):
            # Set the local rank
            set_local_id = f"CHRONOS_LOCALID='{local_task_id}'"
            # We need to compute the global rank with CHRONOS_NODEID, which is unknown when submitting the job.
            global_task_id = f"$((CHRONOS_NODEID * {num_tasks_per_node} + {local_task_id}))"
            set_global_id = f"CHRONOS_PROCID={global_task_id}"
            # LD_PRELOAD needs to be set only when running python, not before, because it
            # breaks unix binaries.
            set_ld_preload = "LD_PRELOAD=$FB_LD_PRELOAD"
            job_id = "${CHRONOS_PARENT_JOB_ID}"
            # Redirect stderr and stdout
            stderr = str(paths.stderr).replace("%j", job_id).replace("%t", global_task_id)
            stdout = str(paths.stdout).replace("%j", job_id).replace("%t", global_task_id)
            # Build the full command for this task
            full_command = (
                f"{set_ld_preload} {set_local_id} {set_global_id} {run_python} "
                f"2> >(tee -ia {stderr} >&2) 1> >(tee -ia {stdout}) &"
            )
            task_commands.append(full_command)

        tasks = "\n".join(task_commands)

        set_env_vars = [f"export {name}={value}" for name, value in self._environ.items()]

        return "\n".join(
            [
                f"# -- Set user defined env variables --",
                *set_env_vars,
                f"",
                f"# -- Set JobEnvironment env variables --",
                # use CHRONOS_GANG_MEMBER_ID if exist, or set to 0
                f"export CHRONOS_NODEID=${{CHRONOS_GANG_MEMBER_ID:-0}}",
                f"export CHRONOS_NTASKS_PER_NODE='{num_tasks_per_node}'",
                f"export CHRONOS_JOB_NUM_NODES='{num_nodes}'",
                f"export CHRONOS_NTASKS='{num_nodes * num_tasks_per_node}'",
                f"echo Logging stdout to {stdout} >&2",
                f"echo Logging stderr to {stderr} >&2",
                f"",
                f"# -- Start python tasks as background processes --",
                tasks,
                f"wait",
                f"",
            ]
        )

    def _make_submission_command(self, submission_file_path: Path) -> List[str]:
        command = ["crun"]
        for key, value in self.parameters.items():
            key = key.replace("_", "-")
            if key not in VALID_KEYS:
                raise ValueError(f"{key} is not a valid parameter.\nValid parameters are: {VALID_KEYS}")
            if key == "ntasks-per-node":
                # This is not used in crun, but to modify the submitted script
                continue
            if key == "name":
                value = utils.sanitize(value)
            command.extend([f"--{key}", str(value)])
        return command + [str(submission_file_path)]

    def _make_submission_file_text(self, command: str, uid: str) -> str:
        """Creates the content of the bash script executed on each machine.

        This script will setup the conda env or the par file on the machine and run the command.
        The default command will run the pickled Callable with python from the conda env/par file.

        Parameters
        ----------
        command: str
            Command to run
        """
        root_folder = utils.JobPaths.get_first_id_independent_folder(self.folder)
        job_id_file = f"{root_folder}/parent_job_id_{uid}"
        if self.conda_env:
            rsync_env = [
                f"",
                f"# -- Specific to conda env file --",
                f"# Untar conda env on local disk",
                f"mkdir -p {_ENVDIR} && tar -xf {self.conda_env} -C {_ENVDIR}",
                f"# For compatibility with par/xar, FB_LD_PRELOAD needs to be set",
                f'export FB_LD_PRELOAD="${{LD_PRELOAD}}"',
                f"echo $FB_LD_PRELOAD",
            ]
        elif self.par_file:
            # a par file is a valid zip file, with a bash script at the beginning
            # When executed, it sets some env variables, then unzip it self and execute
            # the python entry point.
            # We don't execute it, because it would run the wrong entry point.
            # Instead, we unzip it, to have access to the modules inside the par file,
            # and set the right env variables.
            rsync_env = [
                f"",
                f"# -- Specific to par file --",
                f"# unzip the par file on local disk",
                f"mkdir -p {_ENVDIR} && unzip -q {self.par_file} -d {_ENVDIR}",
                f"# Set required env variables",
                f"export LD_LIBRARY_PATH={_ENVDIR}",
                f"export FB_PAR_RUNTIME_FILES={_ENVDIR}",
                f"export FB_PAR_PRELOAD_UNPACK_DIR={_ENVDIR}",
                f"export LC_ALL= LC_CTYPE=en_US.UTF-8",
                f"# Look into the par file to know how to set FB_LD_PRELOAD",
                # -a: to treat binary file as text
                # -o: output only the matching part
                # -P: enable perl-style regex (to use (?<=pattern) and (?=pattern)
                # eval is to do variable expansion of the result of grep
                f"eval export FB_LD_PRELOAD=`grep -a -oP \"(?<=LD_PRELOAD=).*(?='')\" {self.par_file}`",
            ]
        elif self.xar_file:
            # xar file is mounted, and then executes xar_bootstrap.sh, which set several
            # env variables, and start the python entry point.
            # We mount the file, copy the contents to have access to python modules, and
            # set the right env variables.
            rsync_env = [
                f"",
                f"# -- Specific to xar file --",
                f"# mount the xar file and copy the content on local disk",
                f'MOUNT="$(xarexec -m {self.xar_file})" && mkdir {_ENVDIR} && cp -rf ${{MOUNT}}/. {_ENVDIR}',
                f"# Set required env variable",
                f"export LD_LIBRARY_PATH={_ENVDIR}",
                f"export FB_PAR_RUNTIME_FILES={_ENVDIR}",
                f"export LC_ALL= LC_CTYPE=en_US.UTF-8",
                f"# Look into the xar_bootstrap.sh to know how to set FB_LD_PRELOAD",
                # -a: to treat binary file as text
                # -o: output only the matching part
                # -P: enable perl-style regex (to use (?<=pattern) and (?=pattern)
                # eval is to do variable expansion of the result of grep
                f'eval export FB_LD_PRELOAD=`grep -oP "(?<=export LD_PRELOAD=).*" {_ENVDIR}/xar_bootstrap.sh`',
                f"# .so referenced in LD_PRELOAD are relative to {_ENVDIR}",
                f"cd {_ENVDIR}",
            ]
        if self.dev_archive is not None:
            rsync_env += ["# Untar the dev folders on local disk", f"tar -xf {self.dev_archive}"]

        binpath = f"{_ENVDIR}/bin"  # path to env binary (useful only when using a conda env)
        lines = rsync_env + [
            f"",
            f"# -- Get the JOB_ID --",
            # I couldn't find an easier way to get the parent job id from a child job
            f"# Wait for the job_id_file (could take time due to shared FS) (wait up to 120sec, check every 4 sec)",
            f'for i in {{1..30}}; do [ -s {job_id_file} ] && echo "Found job id file" && break || '
            f'(sleep 4 && echo "No job id file. Keep waiting."); done',
            f"# If job id file couldn't be found, exit now",
            f'[[ -s {job_id_file} ]] || (echo "Could not find the job id file" && exit 1)',
            f"# Otherwise, set CHRONOS_PARENT_JOB_ID and keep going",
            f"export CHRONOS_PARENT_JOB_ID=`cat {job_id_file}`",
            f'export PATH=$PATH:"{binpath}"',
            f'echo "Chronos parent job id: $CHRONOS_PARENT_JOB_ID"',
            f"",
            command,
        ]
        return "\n".join(lines)

    def _write_job_id(self, job_id: str, uid: str) -> None:
        root_folder = utils.JobPaths.get_first_id_independent_folder(self.folder)
        parent_job_id_file = root_folder / f"parent_job_id_{uid}"
        with parent_job_id_file.open(mode="w") as idfile:
            idfile.write(job_id)

    @staticmethod
    def _get_job_id_from_submission_command(string: Union[bytes, str]) -> str:
        """Returns the job ID from the output of crun string
        """
        if not isinstance(string, str):
            string = string.decode()
        assert int(string) > 0, f"Unexpected id {string}"
        return string

    @staticmethod
    def _set_job_permissions(folder: Path) -> None:
        os.chmod(folder, 0o777)

    def _set_executor_permissions(self) -> None:
        os.chmod(self._executor_dir, 0o777)
        if self.conda_env:
            os.chmod(self.conda_env, 0o777)
        if self.par_file:
            os.chmod(self.par_file, 0o777)
        if self.dev_archive:
            os.chmod(self.dev_archive, 0o777)
