# pylint: disable=redefined-outer-name
import contextlib
import sys
import time
from pathlib import Path
from typing import Any, Iterator, List, Optional, Union
from unittest.mock import patch

import pytest

from . import _core, submission, utils


class _SecondCall:
    """Helps mocking CommandFunction which is like a subprocess check_output, but
    with a second call.
    """

    def __init__(self, outputs: Any) -> None:
        self._outputs = outputs

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        return self._outputs


class MockedSubprocess:
    """Helper for mocking subprocess calls"""

    SACCT_HEADER = """
           JobID    JobName  Partition    Account  AllocCPUS      State ExitCode
    ------------ ---------- ---------- ---------- ---------- ---------- --------
""".strip(
        "\n"
    )

    SACCT_JOB = """
    {j}                 job  learnfair  fairusers          1    {state}      0:0
    {j}.ext+         extern             fairusers          1    {state}      0:0
    {j}.0            python             fairusers          1    {state}      0:0
""".strip(
        "\n"
    )

    def __init__(
        self, state: str = "RUNNING", job_id: str = "12", shutil_which: Optional[str] = None, array: int = 0
    ) -> None:
        self.state = state
        self.shutil_which = shutil_which
        self.job_id = job_id
        self._sacct = self.sacct(state, job_id, array)
        self._sbatch = f"Running job {job_id}\n".encode()
        self._cinfo = (
            f"tmp,/var/log/chronos/job/2019-01-02-02/1070301003/3759286356/3759286356_tmp)\t(status,0)\t(jobState,{state})\t"
            "(name,crun.lowik.a7dee3f8-2451-4749-84a4-6aaf434f0fdd)\t"
            "(stdout,/var/log/chronos/job/2019-01-02-02/1070301003/3759286356/3759286356_stdout.log)\t"
            f"(hostname,fblearner006.16.ash1.facebook.com)\t(jobId,{job_id})\t(jobInstanceId,3759286356)\t"
            "(stderr,/var/log/chronos/job/2019-01-02-02/1070301003/3759286356/3759286356_stderr.log)\t"
            "(path,/var/log/chronos/job/2019-01-02-02/1070301003/3759286356)\t"
            "(script_path,/var/log/chronos/job/2019-01-02-02/1070301003/3759286356/3759286356)\t"
            "(data,/var/log/chronos/job/2019-01-02-02/1070301003/3759286356/data)\t(message,)"
        )

    def __call__(self, command: str, **kwargs: Any) -> Any:
        if command[0] == "sacct":
            return self._sacct
        elif command[0] == "sbatch":
            return self._sbatch
        elif command[0] == "cinfo":
            return self._cinfo.encode()
        elif command[0] == "crun":
            return str(self.job_id).encode()
        else:
            raise ValueError(f'Unknown command to mock "{command}".')

    def sacct(self, state: str, job_id: str, array: int) -> bytes:
        if array == 0:
            lines = self.SACCT_JOB.format(j=job_id, state=state)
        else:
            lines = "\n".join(self.SACCT_JOB.format(j=f"{job_id}_{i}", state=state) for i in range(array))
        return "\n".join((self.SACCT_HEADER, lines)).encode()

    def which(self, name: str) -> Optional[str]:
        return "here" if name == self.shutil_which else None

    @contextlib.contextmanager
    def context(self) -> Iterator[None]:
        with patch(
            "submitit.utils.CommandFunction", new=lambda *args, **kwargs: _SecondCall(self(*args, **kwargs))
        ):
            with patch("subprocess.check_output", new=self):
                with patch("shutil.which", new=self.which):
                    with patch("subprocess.check_call", return_value=None):
                        yield None


class FakeInfoWatcher(_core.InfoWatcher):

    # pylint: disable=abstract-method
    def get_state(self, job_id: str, mode: str = "standard") -> str:
        return "running"


class FakeJob(_core.Job[_core.R]):

    watcher = FakeInfoWatcher()


class FakeExecutor(_core.PicklingExecutor):
    @property
    def _submitit_command_str(self) -> str:
        return "echo 1"

    def _num_tasks(self) -> int:
        return 1

    def _make_submission_file_text(self, command: str, uid: str) -> str:  # pylint: disable=unused-argument
        """Creates the text of a file which will be created and run
        for the submission (for slurm, this is sbatch file).
        """
        return command + "2"  # this makes "echo 12"

    def _make_submission_command(self, submission_file_path: Path) -> List[str]:
        """Create the submission command.
        """
        with submission_file_path.open("r") as f:
            text: str = f.read()
        return text.split()  # this makes ["echo", "12"]

    @staticmethod
    def _get_job_id_from_submission_command(string: Union[bytes, str]) -> str:
        return string if isinstance(string, str) else string.decode()  # this returns "12"


def _three_time(x: int) -> int:
    return 3 * x


def do_nothing(*args: Any, **kwargs: Any) -> int:
    print("my args", args, flush=True)
    print("my kwargs", kwargs, flush=True)
    if "sleep" in kwargs:
        print("Waiting", flush=True)
        time.sleep(int(kwargs["sleep"]))
    if kwargs.get("error", False):
        print("Raising", flush=True)
        raise ValueError("Too bad")
    print("Finishing", flush=True)
    return 12


def test_fake_job(tmp_path: Path) -> None:
    job: FakeJob[int] = FakeJob(job_id="12", folder=tmp_path)
    repr(job)
    assert not job.done(force_check=True)
    # logs
    assert job.stdout() is None
    assert job.stderr() is None
    with job.paths.stderr.open("w") as f:
        f.write("blublu")
    assert job.stderr() == "blublu"
    # result
    utils.pickle_dump(("success", 12), job.paths.result_pickle)
    assert job.result() == 12
    # exception
    assert job.exception() is None
    utils.pickle_dump(("error", "blublu"), job.paths.result_pickle)
    assert isinstance(job.exception(), Exception)
    with pytest.raises(_core.utils.FailedJobError):
        job.result()


def test_fake_job_cancel_at_deletion(tmp_path: Path) -> None:
    job: FakeJob[Any] = FakeJob(job_id="12", folder=tmp_path).cancel_at_deletion()  # type: ignore
    with patch("subprocess.call", return_value=None) as mock:
        assert mock.call_count == 0
        del job
        assert mock.call_count == 1


def test_fake_executor(tmp_path: Path) -> None:
    executor = FakeExecutor(folder=tmp_path)
    job = executor.submit(_three_time, 8)
    assert job.job_id == "12"
    assert job.paths.submission_file.exists()
    with utils.environment_variables(_TEST_CLUSTER_="chronos", CHRONOS_PARENT_JOB_ID=str(job.job_id)):
        submission.process_job(folder=job.paths.folder)
    assert job.result() == 24


if __name__ == "__main__":
    args, kwargs = [], {}  # oversimplisitic parser
    for argv in sys.argv[1:]:
        if "=" in argv:
            key, val = argv.split("=")
            kwargs[key.strip("-")] = val
        else:
            args.append(argv)
    do_nothing(*args, **kwargs)
