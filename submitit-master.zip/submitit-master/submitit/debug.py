from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Union

from ._core import Executor, InfoWatcher, Job, R
from .utils import DelayedSubmission, UncompletedJobError


class DebugInfoWatcher(InfoWatcher):
    # pylint: disable=abstract-method
    def register_job(self, job_id: str) -> None:
        pass


class DebugJob(Job[R]):
    watcher = DebugInfoWatcher()

    def __init__(self, submission: DelayedSubmission) -> None:
        super().__init__(folder="./tmp", job_id=str(submission))
        self.submission = submission
        self.cancelled = False

    @property
    def num_tasks(self) -> int:
        return 1

    def cancel(self, check: bool = True) -> None:
        self.cancelled = True

    def _check_not_cancelled(self) -> None:
        if self.cancelled:
            raise UncompletedJobError(f"Job {self} was cancelled.")

    def results(self) -> List[R]:
        self._check_not_cancelled()
        return [self.submission.result()]

    def exception(self) -> Optional[BaseException]:  # type: ignore
        self._check_not_cancelled()
        try:
            self.submission.result()
            return None
        except Exception as e:
            # Note that we aren't wrapping the error contrary to what is done in
            # other Executors. It makes the stacktrace smaller and debugging easier.
            return e

    def wait(self) -> None:
        # forces execution.
        self.results()

    def done(self, force_check: bool = False) -> bool:
        # forces execution, in case the client is waiting on it to become True.
        self.results()
        return self.submission.done()

    @property
    def state(self) -> str:
        if self.submission.done():
            return "DONE"
        return "QUEUED"

    def get_info(self) -> Dict[str, str]:
        return {"STATE": self.state}

    def stdout(self) -> Optional[str]:
        # TODO: should we capture stdout/stderr ? This seems to interfere with PDB.
        return None

    def stderr(self) -> Optional[str]:
        return None


class DebugExecutor(Executor):
    def __init__(self, folder: Union[str, Path]):
        super().__init__(folder)

    def submit(self, fn: Callable[..., R], *args: Any, **kwargs: Any) -> Job[R]:
        return DebugJob(DelayedSubmission(fn, *args, **kwargs))
