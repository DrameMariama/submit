import contextlib
import tempfile
from typing import Any, Iterator
from unittest.mock import patch

import pytest

from . import chronos, submission, test_core, utils


def test_chronos_job() -> None:
    with test_core.MockedSubprocess().context():
        job: chronos.ChronosJob[Any] = chronos.ChronosJob(".", "12")
        assert job.state == "RUNNING"
        assert job.stdout() is None


def test_chronos_update_parameters() -> None:
    with mocked_chronos() as tmp:
        executor = chronos.ChronosExecutor(folder=tmp)
        with pytest.raises(ValueError):
            executor.update_parameters(blublu="hop")
        executor.update_parameters(name="hop")
        del executor  # delete before end of context to avoid warning of tmp_dir not existing anymore


@contextlib.contextmanager
def mocked_chronos(state: str = "running", job_id: str = "12") -> Iterator[str]:
    with contextlib.ExitStack() as stack:
        tmp = stack.enter_context(tempfile.TemporaryDirectory())
        stack.enter_context(
            test_core.MockedSubprocess(state=state, job_id=job_id, shutil_which="crun").context()
        )
        stack.enter_context(
            utils.environment_variables(
                **{
                    "CONDA_DEFAULT_ENV": "blublu_path",
                    "CONDA_PREFIX": "blublu",
                    "CHRONOS_PARENT_JOB_ID": f"{job_id}",
                    "_TEST_CLUSTER_": "chronos",
                }
            )
        )
        stack.enter_context(patch("shutil.make_archive", return_value="test_env_blublu.rar"))
        stack.enter_context(patch("submitit.utils._check_python_inside", return_value=None))
        stack.enter_context(patch("os.chmod", return_value=None))
        yield tmp


def test_chronos_mocked() -> None:
    with mocked_chronos() as tmp:
        executor = chronos.ChronosExecutor(folder=tmp)
        executor.update_parameters(name="blublu_job", hostgroup="fblearner_ash_cpuram_default")
        job = executor.submit(test_core.do_nothing, 1, 2, blublu=3)
        assert job.job_id == "12"
        assert job.state == "running"
        assert job.stdout() is None
        job._results_timeout_s = 1
        with pytest.raises(utils.UncompletedJobError):
            job._get_outcome_and_result()
        submission.process_job(job.paths.folder)
        assert job.result() == 12
        del executor  # delete before end of context to avoid warning of tmp_dir not existing anymore
